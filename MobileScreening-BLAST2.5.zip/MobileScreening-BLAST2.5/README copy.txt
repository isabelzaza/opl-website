**ISABEL made a version of this that has no consent form, just the mobile check and a button that says click here to start. Make sure that you MODIFY LINE 10 to point to the experiment URL in line 10, where it says PUT YOUR EXPERIMENT URL HERE***



-> this below are the old instructions from Oakyoon

1) Open consentform.html file with any text editor. I personally recommend Visual Studio Code (https://code.visualstudio.com/).
2) MAKE SURE THAT LINES 21-37 contain the current consent form.
3) MAKE SURE TO MODIFY LINE 10 to point to the experiment URL.
4) Place modified consentform.html file and the two other files (vu-consentform.css, mobile-detect.min.js) in a web server.
  - You may use "GitHub pages" as an alternative to a web server.
5) Now, you can use the link to the "consentform.html" uploaded on the web server.

Ask Oakyoon, if you are not sure what to do.
